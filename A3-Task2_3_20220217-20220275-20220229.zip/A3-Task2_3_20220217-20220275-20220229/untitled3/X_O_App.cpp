#include <iostream>
#include"BoardGame_Classes.hpp"
using namespace std;
int main() {
    int c;
    cout <<"Welcome to X-O Game :)  : \n";
    cout<<"1- 3*3 X-O Game .\n";
    cout<<"2- Pyramid.\n";
    cout<<"3- ConnectFour_Board.\n";
    cout<<"4- Tic-Tac-Toe 5*5 Game.\n";
    cout<<"Enter Your Choice: \n";
    cin>>c;
    switch (c) {
        case 1:{
            Player* players[2];
            players[0] = new Player (1, 'X');
            cout << "Welcome to FCAI X-O Game. :)\n";
            cout << "Press 1 if you want to play with computer: ";
            cin >> c;
            if (c!= 1)
                players[1] = new Player (2, 'O');
            else
                //Player pointer points to child
                players[1] = new RandomPlayer ('O', 3);
            GameManagerXo x_o_game (new X_O_Board(), players);
            x_o_game.run();
            system ("pause");
            break;
        }
        case 2:{
            Player* players[2];
            players[0] = new Player (1, 'X');
            cout << "Welcome to FCAI X-O Game. :)\n";
            cout << "Press 1 if you want to play with computer: ";
            cin >> c;
            if (c != 1)
                players[1] = new Player (2, 'O');
            else
                //Player pointer points to child
                players[1] = new RandomPlayer ('O', 3);
            GameManagerXo x_o_game (new Pyramic(), players);
            x_o_game.run();
            system ("pause");
            break;
        }
        case 3:{
            Player* players[2];
            players[0] = new Player (1, 'X');
            cout << "Welcome to FCAI X-O Game. :)\n";
            cout << "Press 1 if you want to play with computer: ";
            cin >> c;
            if (c != 1)
                players[1] = new Player (2, 'O');
            else
                //Player pointer points to child
                players[1] = new RandomPlayer ('O', 6);
            GameManagerXo x_o_game (new ConnectFour_Board(), players);
            x_o_game.run();
            system ("pause");
            break;
        }
        case 4:{
            Player* players[2];
            players[0] = new Player (1, 'X');
            cout << "Welcome to FCAI X-O Game.)\n";
            cout << "Press 1 if you want to play with computer: ";
            cin >> c;
            if (c != 1)
                players[1] = new Player (2, 'O');
            else
                //Player pointer points to child
                players[1] = new RandomPlayer ('O', 5);
            GameManager x_o_game (new TIC_TAC_TOE_Board(), players);
            x_o_game.run();
            system ("pause");
            break;
        }
    }

}
